const express = require('express');
const path = require('path');
const logger = require('./logger');
const morgan = require('morgan');

const app = express();
const PORT = 3000;

app.use(morgan('combined'));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    logger.info('Home page accessed');
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    logger.info(`Server running on port ${PORT}`);
});
